# ==============================
# INSTALLATION MODULES
# ==============================

import sys
from colorama import Fore, init
import json
import os
import re
import subprocess
import shutil
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import unquote, parse_qs
import psutil
import webbrowser
import qrcode
import socket
import random
import asyncio
import win32com.client
from PyQt5.QtCore import Qt, QPoint
from PyQt5.QtGui import QFont, QColor, QIcon
from PyQt5.QtWidgets import (
    QApplication, QWidget, QPushButton, QVBoxLayout, QHBoxLayout,
    QLineEdit, QLabel, QGraphicsDropShadowEffect
)
# ==============================
# STATISTIQUE
# ==============================

def get_device_uid():
    """
    Génère un UID unique déterministe pour l'appareil à partir du numéro de série.
    """
    output = subprocess.check_output(
            ['powershell', '-Command', "(Get-WmiObject win32_bios).SerialNumber"],
        )
    uid = output.decode().strip()
    if not uid:
        uid = "APP-ERREUR"
    else:
        uid = f"APP-{uid}"
    return uid

def curl_device(base_url="http://filesnet.ddns.net/log.php"):
    uid = get_device_uid()
    url = f"{base_url}?uid={uid}"

    try:
        # Exécute la commande curl et récupère la sortie
        result = subprocess.run(
            ["curl", "-s", url],
            capture_output=True,
            text=True,
            timeout=5
        )
        return result.stdout
    except subprocess.TimeoutExpired:
        return

# ==============================
# CREATION RACCOURCIS
# ==============================
script_dir = os.path.dirname(os.path.abspath(sys.argv[0]))
os.chdir(script_dir)

# Chemin vers l'exécutable FilesNet.exe dans le même dossier
exe_path = os.path.join(os.path.dirname(script_dir), "FilesNet.bat")

# Vérifie que le fichier existe
if not os.path.exists(exe_path):
    erreur = FileNotFoundError(f"Exécutable introuvable : {exe_path}")

# Dossier de démarrage
startup_folder = os.path.join(
    os.getenv('APPDATA'),
    'Microsoft', 'Windows', 'Start Menu', 'Programs', "Startup"
)

# Chemin du raccourci
shortcut_path = os.path.join(startup_folder, "FilesNet.lnk")

# Création du raccourci
shell = win32com.client.Dispatch("WScript.Shell")
shortcut = shell.CreateShortCut(shortcut_path)
shortcut.Targetpath = exe_path
shortcut.WorkingDirectory = script_dir

# Utiliser l'icône de l'exécutable lui-même
icon_path = os.path.join(script_dir, "Menu", "System", "icon.ico")
shortcut.IconLocation = f"{icon_path}, 0"

shortcut.save()

# Variables globales
folder_path = None
init(autoreset=True)
sys.stderr = open(os.devnull, 'w')

# ==============================
# CREATION QR CODE
# ==============================

async def generate_qr_code(ip, port):
    url = f"http://{ip}:{port}"
    print(Fore.YELLOW + f"URL : {url}")
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=2,
    )
    qr.add_data(url)
    qr.make(fit=True)

    img = qr.make_image(fill_color="black", back_color=(240, 244, 248))
    img.save("System/qr_code.png")

# ==============================
# DEFINIR POSITIONS DOSSIERS
# ==============================

async def setup_directories():
    global folder_path
    base_path = Path(__file__).resolve().parent
    os.chdir(base_path)
    folder_path = base_path / 'Menu'

    if not folder_path.exists():
        folder_path.mkdir(parents=True, exist_ok=True)

    os.chdir(folder_path)
    user_home = Path.home()
    workspace_folder = folder_path / "Espace de Travail"
    appdata_folder = user_home / "AppData/Roaming/FilesNet"

    appdata_folder.mkdir(parents=True, exist_ok=True)

    try:
        for item in appdata_folder.iterdir():
            destination_item = workspace_folder / item.name
            if item.is_dir():
                shutil.copytree(item, destination_item, dirs_exist_ok=True)
            else:
                shutil.copy2(item, destination_item)
    finally:
        pass

# ==============================
# AFFICHAGE    |   BAR DE DISQUE WEB
# ==============================

def get_metrics():
    disk_usage = psutil.disk_usage('/').percent
    return {'disk': disk_usage}

# ==============================
# FONCTION WEB
# ==============================

class FileHandler(SimpleHTTPRequestHandler):
    def do_GET(self):
        path_mapping = {
            '/': '/System/index.html',
        }

        if self.path in path_mapping:
            self.path = path_mapping[self.path]
        elif self.path == '/metrics':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            metrics = get_metrics()
            self.wfile.write(json.dumps(metrics).encode())
            return
        elif self.path == '/stop':
            sys.exit()
        elif self.path.startswith('/files'):
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            query = unquote(self.path.split('?path=')[-1])
            path = Path(query) if query else Path('.')
            if path.is_dir():
                files = [{'name': f.name, 'path': str(f), 'isDirectory': f.is_dir()} for f in path.iterdir()]
                self.wfile.write(json.dumps(files).encode())
            else:
                self.wfile.write(json.dumps([]).encode())
            return
        elif self.path.startswith('/fileinfo'):
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            query = unquote(self.path.split('?path=')[-1])
            path = Path(query)
            info = {'isDirectory': path.is_dir()}
            self.wfile.write(json.dumps(info).encode())
            return
        elif self.path.startswith('/edit'):
            query = unquote(self.path.split('?path=')[-1])
            path = Path(query)
            if path.exists() and path.is_file():
                self.send_response(200)
                self.send_header('Content-type', 'text/plain')
                self.end_headers()
                with open(path, 'r', encoding='utf-8') as file:
                    self.wfile.write(file.read().encode())
            else:
                self.send_response(404)
                self.end_headers()
            return
        elif self.path.startswith('/download'):
            download_type = self.path.split('type=')[-1]
            query = unquote(self.path.split('?path=')[-1])
            if re.search("&type=directory", query):
                query = query.replace("&type=directory", "")
            elif re.search("&type=file", query):
                query = query.replace("&type=file", "")
            else:
                print("Erreur dans le nom du Fichier / Dossier.")
            path = Path(query)
            if path.exists():
                if download_type == 'file':
                    self.send_response(200)
                    self.send_header('Content-Disposition', f'attachment; filename="{path.name}"')
                    self.end_headers()
                    with open(path, 'rb') as file:
                        shutil.copyfileobj(file, self.wfile)
                elif download_type == 'directory':
                    zip_path = shutil.make_archive(str(path), 'zip', root_dir=path.parent, base_dir=path.name)
                    self.send_response(200)
                    self.send_header('Content-Disposition', f'attachment; filename="{path.name}.zip"')
                    self.end_headers()
                    with open(zip_path, 'rb') as file:
                        shutil.copyfileobj(file, self.wfile)
                    os.remove(zip_path)
            else:
                self.send_response(404)
                self.end_headers()
            return
        return  super().do_GET()

    def do_DELETE(self):
        if self.path.startswith('/delete'):
            query = unquote(self.path.split('?path=')[-1])
            path = Path(query)
            if path.exists():
                if path.is_file():
                    path.unlink()
                else:
                    shutil.rmtree(path)
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({'success': True}).encode())
            else:
                self.send_response(404)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({'success': False}).encode())
            return

    def do_POST(self):
        if self.path.startswith('/rename'):
            query = parse_qs(unquote(self.path.split('?')[-1]))
            path = Path(query['path'][0])
            new_name = query['newName'][0]
            new_path = path.with_name(new_name)
            if re.search("/", new_name):
                shutil.move(new_path, str(folder_path))
            if path.exists():
                path.rename(new_path)
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({'success': True}).encode())
            else:
                self.send_response(404)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({'success': False}).encode())
            return
        elif self.path.startswith('/save'):
            query = parse_qs(unquote(self.path.split('?')[-1]))
            path = Path(query['path'][0])
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            data = json.loads(post_data)
            if path.exists() and path.is_file():
                with open(path, 'w', encoding='utf-8') as file:
                    file.write(data['content'])
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({'success': True}).encode())
            else:
                self.send_response(404)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({'success': False}).encode())
            return
        elif self.path.startswith('/create'):
            query = parse_qs(unquote(self.path.split('?')[-1]))
            item_type = query['type'][0]
            name = query['name'][0]
            path = Path(query.get('path', [''])[0])
            full_path = path / name
            try:
                if item_type == 'fichier':
                    full_path.touch()
                elif item_type == 'dossier':
                    full_path.mkdir(parents=True, exist_ok=True)
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({'success': True}).encode())
            except Exception as e:
                self.send_response(500)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({'success': False, 'error': str(e)}).encode())
            return

# ==============================
# OPTENIR IP LOCAL
# ==============================

async def get_local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
    finally:
        s.close()
    return local_ip

# ==============================
# LANCEMENT SERVEUR LOCAL
# ==============================

async def run(server_class=HTTPServer, handler_class=FileHandler, port=1024):
    global folder_path
    if folder_path is None:
        raise ValueError("folder_path is not defined")
    server_address = ('', port)
    httpd = server_class(server_address, handler_class)
    await generate_qr_code(ip, port)
    httpd.serve_forever()


async def get_html_path():
    current_dir = Path(__file__).resolve().parent
    html_path = current_dir / 'index.html'
    return html_path

# ==============================
# SCRIPTS & PLUGINS
# ==============================

async def scripts_python():
    global folder_path
    if folder_path is None:
        raise ValueError(Fore.LIGHTRED_EX + "folder_path is not defined")
    repertoire_plugin = folder_path / "Espace de Travail/System/Plugin"
    for fichier in repertoire_plugin.iterdir():
        if fichier.suffix == '.py' and fichier.name != Path(__file__).name:
            print(f"Exécution de {fichier.name}...")
            try:
                subprocess.run(['python', fichier], check=True)
            except subprocess.CalledProcessError as e:
                print(f"Erreur lors de l'exécution de {fichier.name}: {e}")

# ==============================
# GUI UTILISATEUR
# ==============================
async def create_gui():
    class FilesNetApp(QWidget):
        def __init__(self):
            super().__init__()
            self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
            self.setAttribute(Qt.WA_TranslucentBackground)
            self.resize(300, 300)
            self.setWindowTitle("FilesNet")

            # --- Icône de la fenêtre ---
            icon_path = os.path.join(script_dir, "Menu", "System", "icon.ico")
            self.setWindowIcon(QIcon(icon_path))

            # Position drag
            self.dragPos = QPoint()

            # --- Cadre principal ---
            self.main_frame = QWidget(self)
            self.main_frame.setStyleSheet("""
                QWidget {
                    background-color: rgba(20, 20, 20, 230); /* Fond sombre FilesNet */
                    border-radius: 8px;
                }
            """)
            self.main_frame.setGeometry(0, 0, 300, 300)

            # --- Ombre subtile ---
            shadow = QGraphicsDropShadowEffect(self)
            shadow.setBlurRadius(25)
            shadow.setXOffset(0)
            shadow.setYOffset(0)
            shadow.setColor(QColor(120, 120, 120, 100))
            self.main_frame.setGraphicsEffect(shadow)

            # --- Layout global ---
            main_layout = QVBoxLayout(self.main_frame)
            main_layout.setContentsMargins(40, 20, 40, 30)
            main_layout.setSpacing(20)

            # --- Top bar ---
            top_bar = QHBoxLayout()
            top_bar.setContentsMargins(0, 0, 0, 0)

            # Titre (sans fond derrière)
            title = QLabel("FilesNet")
            title.setFont(QFont("Segoe UI", 20, QFont.Bold))
            title.setStyleSheet("color: white; background: transparent;")

            self.close_btn = QPushButton("✕", self)
            self.close_btn.setFixedSize(20, 20)
            self.close_btn.setStyleSheet("""
                QPushButton {
                    color: #666;
                    background: transparent;
                    border: none;
                }
                QPushButton:hover {
                    color: white;
                }
            """)
            self.close_btn.clicked.connect(self.close_app)

            top_bar.addWidget(title, alignment=Qt.AlignLeft)
            top_bar.addStretch()
            top_bar.addWidget(self.close_btn, alignment=Qt.AlignRight)

            main_layout.addLayout(top_bar)

            # --- Champ de saisie (Port serveur) ---
            self.port_entry = QLineEdit()
            self.port_entry.setPlaceholderText("Port entre 1024 et 49150 (facultatif)")
            self.port_entry.setStyleSheet("""
                QLineEdit {
                    border-radius: 6px;
                    padding: 8px;
                    background-color: rgba(30,30,30,240);
                    color: white;
                    border: 1px solid #555;
                }
                QLineEdit:focus {
                    border: 1px solid white;
                }
            """)
            main_layout.addWidget(self.port_entry)

            # --- Boutons (liés aux vraies fonctions) ---
            self.add_button(main_layout, "Démarrer le serveur", self.start_server)
            self.add_button(main_layout, "Dossier Plugin", self.open_plugin)
            self.add_button(main_layout, "Support",
                            lambda: webbrowser.open("http://filesnet.ddns.net/tickets/support.php"))

        @staticmethod
        def add_button(layout, text, func):
            btn = QPushButton(text)
            btn.setFixedHeight(40)
            btn.setStyleSheet("""
                QPushButton {
                    border-radius: 5px;
                    background-color: #1a1a1a;
                    color: white;
                    font: bold 13px 'Segoe UI';
                    border: 1px solid #444;
                }
                QPushButton:hover {
                    background-color: #2a2a2a;
                    border: 1px solid white;
                }
                QPushButton:pressed {
                    background-color: black;
                    color: #aaa;
                }
            """)
            btn.clicked.connect(func)
            layout.addWidget(btn)

        # --- Déplacement de la fenêtre ---
        def mousePressEvent(self, event):
            if event.button() == Qt.LeftButton:
                self.dragPos = event.globalPos()

        def mouseMoveEvent(self, event):
            if event.buttons() == Qt.LeftButton:
                delta = QPoint(event.globalPos() - self.dragPos)
                self.move(self.x() + delta.x(), self.y() + delta.y())
                self.dragPos = event.globalPos()

        # --- Fonctions logiques réelles ---
        def start_server(self):
            global port
            port = self.port_entry.text()  # stocke le port
            QApplication.instance().quit()  # quitte proprement la boucle Qt

        @staticmethod
        def open_plugin():
            global folder_path
            plugin_path = os.path.join(folder_path, "Espace de Travail/System/Plugin") if folder_path else None
            if plugin_path and os.path.exists(plugin_path):
                os.startfile(plugin_path)
            else:
                print("Script des Plugins infonctionnel.")

        def close_app(self):
            self.close()

    html_path = await get_html_path()
    if os.path.exists(html_path):
        with open(html_path, 'r') as file:
            html_content = file.read()
        return html_content

    # ==============================
    # LANCEMENT DEMANDE PORT
    # ==============================

    if __name__ == "__main__":
        app = QApplication(sys.argv)
        app.setWindowIcon(QIcon(icon_path))
        app.setStyle("Fusion")
        window = FilesNetApp()
        window.show()
        app.exec_()

# ==============================
# ADMINISTRATEUR
# ==============================

async def admin():
    global port
    try:
        port = int(port)
    except ValueError:
        if port == "Admin":
            print(Fore.YELLOW + "Mode Administrateur")
            sys.stderr = sys.__stderr__
            port = 49151
        else:
            port = 49151

    if not (1024 <= port <= 49150):
        port = random.randint(1024, 49150)

# ==============================
# LANCEMENT GLOBAL
# ==============================

if __name__ == "__main__":
    curl_device()
    asyncio.run(setup_directories())
    asyncio.run(create_gui())
    asyncio.run(admin())

    ip = asyncio.run(get_local_ip())
    global port

    if not ip:
        ip = socket.gethostbyname(socket.gethostname())
    print(port, flush=True)  # Important : flush pour envoi instantané !

    asyncio.run(scripts_python())
    asyncio.run(run(port=port))
