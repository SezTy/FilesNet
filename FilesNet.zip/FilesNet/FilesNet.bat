@echo off
setlocal enableextensions enabledelayedexpansion
chcp 65001 >nul 2>&1
color 0F
title FilesNet

REM ==== Vérif/Création Version ====
set DISTANT_JSON_URL=http://filesnet.ddns.net/logiciel/version.json
set DISTANT_JSON_FILE=Menu\System\version_distante.json
set LOCAL_JSON_FILE=Menu\System\version.json


REM Crée un fichier version local par défaut si inexistant
if not exist "%LOCAL_JSON_FILE%" (
    echo {"version": "0.0.0"} > "%LOCAL_JSON_FILE%"
)


REM Télécharge la version distante
curl -s -o "%DISTANT_JSON_FILE%" "%DISTANT_JSON_URL%"
if errorlevel 1 (
    color 4f
    echo FILESNET : Erreur d'installation. [1]
    echo Pour plus d'informations, contactez notre service d'assistance :
	echo SITE WEB : http://filesnet.ddns.net/tickets/support.php
	echo EMAIL    : sezty84@gmail.com 
    pause
    exit /b 1
)


REM Extrait la version locale (p.ex : {"version": "1.4.2"})
set "local_ver="
for /f "tokens=2 delims=:" %%A in ('type "%LOCAL_JSON_FILE%" ^| findstr "version"') do (
    set "local_ver=%%A"
)
REM Supprime les espaces, guillemets et accolades
set "local_ver=!local_ver:"=!"
set "local_ver=!local_ver: =!"
set "local_ver=!local_ver:{=!"
set "local_ver=!local_ver:}=!"
set "local_ver=!local_ver:,=!"

REM Extrait la version distante
set "remote_ver="
for /f "tokens=2 delims=:" %%A in ('type "%DISTANT_JSON_FILE%" ^| findstr "version"') do (
    set "remote_ver=%%A"
)
set "remote_ver=!remote_ver:"=!"
set "remote_ver=!remote_ver: =!"
set "remote_ver=!remote_ver:{=!"
set "remote_ver=!remote_ver:}=!"
set "remote_ver=!remote_ver:,=!"


REM Compare les numéros de version (simple, premier chiffre)
set "maj_needed=0"
for /f "delims=. tokens=1-3" %%L in ("!local_ver!") do (
    set "l0=%%L" & set "l1=%%M" & set "l2=%%N"
)
for /f "delims=. tokens=1-3" %%R in ("!remote_ver!") do (
    set "r0=%%R" & set "r1=%%S" & set "r2=%%T"
)

REM Comparaison sémantique simplifiée
if !r0! gtr !l0! set "maj_needed=1"
if !r0! equ !l0! if !r1! gtr !l1! set "maj_needed=1"
if !r0! equ !l0! if !r1! equ !l1! if !r2! gtr !l2! set "maj_needed=1"

if "!maj_needed!"=="1" (
    echo FILESNET : Version !local_ver!
    echo La mise à jour !remote_ver! est disponible : http://filesnet.ddns.net/
	echo.
	echo FILESNET : Le logiciel est en cours de lancement.
) else (
    echo FILESNET : Version !local_ver!
	echo FILESNET : Le logiciel est en cours de lancement.
)

if not exist .\Menu\System\local (
    python -m venv .\Menu\System\local
    if errorlevel 1 (
		color 4f
		echo FILESNET : Erreur d'installation. [2]
		echo Pour plus d'informations, contactez notre service d'assistance :
		echo SITE WEB : http://filesnet.ddns.net/tickets/support.php
		echo EMAIL    : sezty84@gmail.com 
        pause
        exit /b 1
    )
)
pip install --upgrade pip >nul 2>&1
call .\Menu\System\local\Scripts\activate >nul 2>&1

pip install -r .\Menu\System\requirement.txt >nul 2>&1

if errorlevel 1 (
    curl -o .\Menu\System\requirement.txt http://filesnet.ddns.net/logiciel/requirement.txt >nul 2>&1
    timeout /t 2 /nobreak >nul
	color 4f
	echo FILESNET : Erreur d'installation. [3]
	echo Relancez le logiciel, si le problème persiste, contactez notre service d'assistance :
	echo SITE WEB : http://filesnet.ddns.net/tickets/support.php
	echo EMAIL    : sezty84@gmail.com 
)
cls
color 0F
echo FILESNET : Instance en cours d'execution...
python FilesNet.py
pause

cls
echo FILESNET : Instance en cours d'extinction...

