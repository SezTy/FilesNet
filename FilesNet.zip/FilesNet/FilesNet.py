import webview

BAR_HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>FilesNet</title>
  <style>
    html,body {{
      margin:0; padding:0; box-sizing:border-box;
      height:100%; width:100vw; background:#181818;
      font-family:'Rajdhani', 'Segoe UI', Arial, sans-serif;
    }}
    .topbar {{
      position:fixed; z-index:1000; left:0; top:0;
      width:100vw; height:72px;
      background: linear-gradient(90deg,#191919 70%,#232323 100%);
      display:flex; align-items:center; padding:0 34px;
      box-shadow: 0 2px 16px #000b, 0 2px 4px #0008;
      border-bottom: 1.5px solid #292929;
      user-select: none;
    }}
    .logo {{
      margin-right:21px;margin-left:6px;
    }}
    .logo svg{{
      display:block;
      width:40px; height:40px;
    }}
    .apptitle {{
      font-size:1.19em;font-weight:700;letter-spacing:0.09em;
      color:#fff;margin-right:37px;text-shadow:0 2px 17px #000;
    }}
    .canalLabel {{
      font-size:1em; color:#fff; font-weight:600; margin-right:13px; letter-spacing:.03em;
    }}
    .canalInputWrap{{
      display:inline-flex;align-items:center;gap:0;
      background:#222;
      border-radius:14px;box-shadow:0 2px 9px #0006;
      padding:2px 0;
    }}
    .canalInput {{
      background:transparent; border:none; color:#fff;
      font-size:31px; padding:5px 5px; border-radius:0; outline:none;
      width:150px; text-align:center;font-weight:700; letter-spacing:0.08em;
      box-shadow:none; margin:0 10px;
      transition:box-shadow .17s, border .23s;
      border-radius:10px;
      font-family:'Rajdhani', 'Segoe UI', Arial, sans-serif;
    }}
    .canalInput::-webkit-outer-spin-button, .canalInput::-webkit-inner-spin-button {{
      -webkit-appearance: none; margin: 0;
    }}
    .canalBtn {{
      appearance:none;
      background:transparent;
      border:none;
      color:#fff;
      font-size:34px;
      font-weight:700;
      width:38px;height:38px;
      border-radius:13px;display:flex;
      align-items:center;justify-content:center;
      transition:background .19s;
      cursor:pointer;
      margin:0 2px;
    }}
    .canalBtn:active,.canalBtn:focus {{ background:#333; color:#eee; }}
    .canalBtn svg{{display:block; width:24px; height:24px;}}
    .canalChanged {{
      font-size:1.12em;font-weight:600;color:#fff;background:#232323e6;
      border-radius:8px;margin-left:20px;padding:5px 24px;opacity:0;
      border:1.5px solid #fff;transition:opacity .21s;
      text-shadow:0 1px 8px #000;
    }}
    .canalChanged.visible {{ opacity:1; }}
    #mainframe {{
      display:block; width:100vw; position:fixed; left:0; top:72px;
      border:none;height:calc(100vh - 72px); background:#fff;
      z-index:10;
    }}
    #loader {{
      position:fixed; z-index:10001; inset:72px 0 0 0; width:100vw; height:calc(100vh - 72px);
      background:rgba(30,30,30,0.96);
      display:flex; flex-direction:column; align-items:center; justify-content:center;
      transition:opacity .46s, visibility .37s;
      opacity:0; visibility:hidden;
    }}
    #loader.active {{ opacity:1; visibility:visible; }}
    .progress-cycle {{
      width:68px; height:68px; border-radius:50%;
      border:7px solid #fff; border-bottom-color:#232323; border-left-color:#838383;
      box-sizing:border-box;
      margin-bottom:31px;
      animation: cycleSpin 1.085s linear infinite;
    }}
    @keyframes cycleSpin {{
      to {{ transform:rotate(360deg); }}
    }}
    .loader-text {{
      color:#fff; font-size:1.25em; font-weight:800; letter-spacing:0.04em;
      margin-top:-8px;text-align:center;
      text-shadow:0 2px 18px #0008;
    }}
    #error-page {{
      background:#fafafa; color:#181818; display:flex; 
      flex-direction:column; align-items:center; justify-content:center;
      height:100%; font-weight:800; font-size:1.41em; letter-spacing:0.07em; font-family:'Rajdhani',Arial,sans-serif;
    }}
    #error-page .err-ico {{ font-size:2.4em; margin-bottom:20px; opacity:.7; }}
    #error-page .err-title {{ font-size:1.13em; font-weight:700; }}
    #error-page .err-desc {{ font-size:1em; font-weight:500; color:#444; margin-top:12px; }}
  </style>
</head>
<body>
  <div class="topbar">
    <span class="apptitle">FilesNet</span>
    <label for="canal-input" class="canalLabel">Canal de travail :</label>
    <span class="canalInputWrap">
      <button id="dec-btn" class="canalBtn" title="Canal précédent">
        <svg viewBox="0 0 20 20"><path fill="currentColor" d="M13 17l-7-7 7-7"/></svg>
      </button>
      <input id="canal-input" class="canalInput" type="number" value="{canal}" min="1" max="65535">
      <button id="inc-btn" class="canalBtn" title="Canal suivant">
        <svg viewBox="0 0 20 20"><path fill="currentColor" d="M7 3l7 7-7 7"/></svg>
      </button>
    </span>
    <span id="canal-changed" class="canalChanged">Canal changé !</span>
  </div>
  <div id="loader" class=""><div class="progress-cycle"></div>
    <div class="loader-text">Chargement du canal…</div>
  </div>
  <iframe id="mainframe" src="http://localhost:{canal}/" allowfullscreen></iframe>
  <script>
    const input = document.getElementById('canal-input');
    const changed = document.getElementById('canal-changed');
    const frame = document.getElementById('mainframe');
    const loader = document.getElementById('loader');
    const dec = document.getElementById('dec-btn');
    const inc = document.getElementById('inc-btn');
    function clampCanal(v) {{
      v = parseInt(v) || 1;
      return Math.max(1, Math.min(65535, v));
    }}
    function showLoader() {{
      loader.classList.add('active');
    }}
    function hideLoader() {{
      loader.classList.remove('active');
    }}
    function loadCanal(url) {{
      showLoader();
      frame.style.opacity = ".1";
      frame.src = url;
    }}
    input.addEventListener('change', function() {{
      let v = clampCanal(input.value);
      input.value = v;
      changed.classList.add('visible');
      setTimeout(()=>{{changed.classList.remove('visible');}},1200);
      loadCanal('http://localhost:' + v + '/');
    }});
    input.addEventListener('keyup', function(e){{
      if(e.key==="Enter") input.dispatchEvent(new Event('change'));
    }});
    inc.addEventListener('click', function() {{
      input.value = clampCanal(Number(input.value)+1);
      input.dispatchEvent(new Event('change'));
    }});
    dec.addEventListener('click', function() {{
      input.value = clampCanal(Number(input.value)-1);
      input.dispatchEvent(new Event('change'));
    }});
    // Loader et gestion d'erreur de l'iframe
    frame.addEventListener('load', function() {{
      hideLoader(); frame.style.opacity = "1";
      // Vérifie si le canal existe (cas: très peu de contenu ou erreur)
      let error = false;
      try {{
        if (!frame.contentWindow || !frame.contentDocument || typeof frame.contentDocument.body === 'undefined') {{
          error = true;
        }} else {{
          if (frame.contentDocument.body.innerText.replace(/\\s/g,'').length<8)
            error = true;
        }}
      }} catch(e) {{
        error = true;
      }}
      if(error) {{
        frame.contentDocument.open();
        frame.contentDocument.write(`
      <div id="error-page">
        <div class="err-ico">🚫</div>
        <div class="err-title">Le canal diffusé n'existe pas</div>
        <div class="err-desc">Page ou serveur inexistant.<br>Vérifiez le canal ou contactez le support.</div>
      </div>
        `);
        frame.contentDocument.close();
      }}
    }});
    frame.addEventListener('error', function() {{
      hideLoader();
      frame.contentDocument.open();
      frame.contentDocument.write(`
      <div id="error-page">
        <div class="err-ico">🚫</div>
        <div class="err-title">Le canal diffusé n'existe pas</div>
        <div class="err-desc">Page ou serveur inaccessible.<br>Vérifiez le canal ou contactez le support.</div>
      </div>
      `);
      frame.contentDocument.close();
    }});
  </script>
</body>
</html>
"""
import subprocess
import re

proc = subprocess.Popen(
    ["python", "CanalNet.py"],
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    text=True
)

current_canal = None
while True:
    line = proc.stdout.readline()
    if not line: break  # Fin du process ou sortie fermée
    match = re.search(r'\d+', line)
    if match:
        current_canal = int(match.group())
        break
if current_canal is None:
    print("[translate:Aucune valeur de canal trouvée dans la sortie.]")
    print(current_canal)

def get_bar_html():
    return BAR_HTML_TEMPLATE.format(canal=current_canal)

window = webview.create_window(
    'FilesNet',
    html=get_bar_html(),
    width=1100,
    height=870,
    frameless=True,
    background_color='#181818'
)

try:
    webview.start(icon='C:\\Windows\\System32\\shell32.dll')
except Exception as e:
    print(f"Erreur lors du Lancement, télécharger FilesNet de nouveau ou contacter le Support. ;{e};")
    import webbrowser
    webbrowser.open_new_tab(f"http://localhost:{port}")

